# Richardson Emergency Plumber rebuild

Domain: https://richardsonemergencyplumber.com
Phone retained from the live site: 877-552-8556
Build date: 2026-08-13

## Included
- Homepage
- 10 service pages with the existing URL slugs
- 15 neighborhood pages with the existing URL slugs
- Blog index + 10 legacy blog URLs
- robots.txt and sitemap.xml
- JSON-LD schema (Organization, WebSite, WebPage, Service, CollectionPage, BlogPosting, BreadcrumbList, FAQPage, ItemList)
- Netlify `_redirects`, `_headers`, and `netlify.toml`
- Netlify Forms-compatible service request form
- Mobile sticky call CTA
- No fake reviews, physical address, license number, aggregate rating or guaranteed response-time claims

## Important domain migration step
Deploy this build to the existing Netlify site if possible, add `richardsonemergencyplumber.com` as the custom domain, and keep the included host-level redirect so the old netlify.app URLs 301 to the matching path on the custom domain.

## Before launch
1. Confirm the call-tracking number 877-552-8556 is still correct.
2. If you have a real plumbing partner, replace the footer disclosure and add verified business NAP/license data.
3. If you have verified reviews, add them in visible copy before adding Review/AggregateRating schema.
4. Submit `https://richardsonemergencyplumber.com/sitemap.xml` in Google Search Console after the custom domain is live.
