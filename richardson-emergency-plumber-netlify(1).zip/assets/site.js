
const menuBtn=document.querySelector('.menu-btn');const nav=document.querySelector('.navlinks');if(menuBtn&&nav){menuBtn.addEventListener('click',()=>{nav.classList.toggle('open');menuBtn.setAttribute('aria-expanded',nav.classList.contains('open'))})}
for(const a of document.querySelectorAll('.navlinks a')){a.addEventListener('click',()=>nav?.classList.remove('open'))}
